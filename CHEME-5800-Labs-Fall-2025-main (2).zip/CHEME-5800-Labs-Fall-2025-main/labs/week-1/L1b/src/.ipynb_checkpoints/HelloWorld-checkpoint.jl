function printgreeting()
    return "Hello World!"
end

# What happens if we uncomment the last line and include the file in the REPL?
printgreeting()