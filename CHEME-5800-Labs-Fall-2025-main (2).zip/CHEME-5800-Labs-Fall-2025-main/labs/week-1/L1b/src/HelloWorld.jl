function printgreeting()::String
    return "Hello World! - it's morning!"
end

# What happens if we uncomment the last line and include the file in the REPL?
printgreeting()